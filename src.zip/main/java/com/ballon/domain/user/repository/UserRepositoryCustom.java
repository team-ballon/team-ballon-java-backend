package com.ballon.domain.user.repository;

public interface UserRepositoryCustom {

}
