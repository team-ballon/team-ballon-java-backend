package com.ballon.domain.admin.service;

public interface PermissionService {
}
